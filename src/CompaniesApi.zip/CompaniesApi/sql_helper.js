'use strict'

modules.export = {
    QUERY_GET_COMPANIES_DATA : `select * from companies c `
}